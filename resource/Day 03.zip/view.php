<?php
include_once 'db.php';
global $db;
$id = $_GET['id'];

$stm = "SELECT * FROM users WHERE id = $id";
$result = $db->query($stm);
$row = $result->fetch();
if(!$row){
    header('Location: index.php');
    exit();
}

