<?php
include_once 'layout/header.php';
?>

    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto my-5">
                <?php
                if(isset($_SESSION['errors'])){
                    foreach ($_SESSION['errors'] as $error) {
                        ?>
                        <div class="alert alert-danger">
                            <?= $error ?>
                        </div>
                        <?php
                    }
                }
                ?>
                <form action="store.php" method="post" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input type="text" name="name" class="form-control" placeholder="name">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" placeholder="email">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" placeholder="password">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone</label>
                        <input type="tel" name="phone" class="form-control" placeholder="Phone">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Upload Avatar</label>
                        <input class="form-control" type="file" name="photo">
                    </div>
                    <button class="btn btn-primary">
                        Save
                    </button>
                </form>
            </div>
        </div>
    </div>

<?php
include_once 'layout/footer.php';
?>