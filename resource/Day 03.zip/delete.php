<?php

include_once 'db.php';
global $db;

if (!isset($_GET['id']) || !is_numeric($_GET['id'])){

    header('Location: index.php');
    exit();
}

$id = $_GET['id'];

$stm = "SELECT photo FROM users WHERE id = $id";
$result = $db->query($stm);
$row = $result->fetch();
if($row){
    unlink($row['photo']);
}else{
    header('Location: index.php');
    exit();
}

$stm = "DELETE FROM users where id = $id";
$db->exec($stm);

header("Location: index.php");
exit();
