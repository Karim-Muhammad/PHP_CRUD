<?php

session_start();
$errors = [];
if(isset($_POST['name']) && !empty($_POST['name'])){

}else{
    $errors[] = "Name is required";
}

if (isset($_POST['email'])  && !empty($_POST['email'])){

}else{
    $errors[] = "Email is required";
}

if(isset($_POST['password'])  && !empty($_POST['password'])){

}else{
    $errors[] = "password is required";
}

if(isset($_POST['phone']) && !empty($_POST['phone'])){

}else{

    $errors[] = "phone is required";
}


if (isset($_FILES['photo'])){

}else{
    $errors[] = "photo is required";
}


if (count($errors) > 0){
    $_SESSION['errors'] = $errors;
    header('Location: create.php');
    exit();
}

// clear session
unset($_SESSION['errors']);

// Lab

// 1- Validation
// 2- extra : old data
// 3- save image
// 4- insert on table
