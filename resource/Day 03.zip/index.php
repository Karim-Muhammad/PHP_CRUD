<?php
include_once "db.php";
include_once 'layout/header.php';
?>
<table class="table table-dark mt-5">
    <thead>
    <tr>
        <th scope="col">#</th>
        <th scope="col">Name</th>
        <th scope="col">Email</th>
        <th scope="col">Phone</th>
        <th scope="col">Avatar</th>
        <th scope="col">Action</th>
    </tr>
    </thead>
    <tbody>
    <?php
        global $db;
        $sql = "SELECT * FROM users";
        $result = $db->query($sql);
        while ($row = $result->fetch(PDO::FETCH_ASSOC)){
    ?>

    <tr>
        <th scope="row"><?= $row['id'] ?></th>
        <td><?= $row['name'] ?></td>
        <td><?= $row['email'] ?></td>
        <td><?= $row['phone'] ?></td>
        <td><img src="<?= $row['photo'] ?>"  width="80"></td>
        <td>

            <a href="delete.php?id=<?= $row['id'] ?>" class="btn btn-danger">delete</a>
        </td>
    </tr>


    <?php
        }
    ?>
<?php
include_once 'layout/footer.php';
